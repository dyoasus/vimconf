VIM TypeScript Readme
----------------------------------------------------------------------------
Author: Microsoft Open Technologies, Inc.

TypeScript bundle for VIM, this bundle provides syntax highlighting.

This is provided as a sample to help you get started coding with TypeScript in VIM

## Feature
1. TypeScript language syntax highlighting 

## Installation
Installation instructions can be found here: http://vim.wikia.com/wiki/Creating_your_own_syntax_files